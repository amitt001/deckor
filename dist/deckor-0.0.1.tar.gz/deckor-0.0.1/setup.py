from setuptools import setup

packages = [
    "deckor",
]

setup(
    name='deckor',
    version='0.0.1',
    packages=packages,
)
